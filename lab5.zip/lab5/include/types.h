#ifndef _TYPE_H
#define _TYPE_H

typedef unsigned long long uint64;
typedef unsigned long* pagetable_t;

#endif

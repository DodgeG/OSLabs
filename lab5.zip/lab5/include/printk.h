#ifndef _PRINTK_H_
#define _PRINTK_H_

#include "stddef.h"

int printk(const char *, ...);

#endif
#include "print.h"
#include "sbi.h"

void puts(char *s) {
    // unimplemented
    while(*s)
    {
        sbi_ecall(0x1, 0x0, *s, 0, 0, 0, 0, 0);
        s++;
    }
}

void puti(int x) {
    // unimplemented
    int bit[100];
    int count = 0;
    while(x)
    {
        bit[count++] = x % 10;
        x /= 10;
    }
    for(int i = count - 1; i >= 0; i--)
        sbi_ecall(0x1, 0x0, bit[i]+'0', 0, 0, 0, 0, 0);
}

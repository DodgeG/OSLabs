#ifndef _CLOCK_H_
#define _CLOCK_H_

unsigned long get_cycles();
void clock_set_next_event();

#endif